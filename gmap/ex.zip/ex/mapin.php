<!DOCTYPE html>
<html>

<head>
<title>batinfo</title>

<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="css/theme.css">
<link rel="stylesheet" type="text/css" href="CS4.css">
<link rel="stylesheet" type="text/css" href="css/style(2).css">
<script src="js//jquary.js"></script>
<script src="js//bootstrapjs.js"></script>


</head>
<body>


<div class="row">
	<div class="col-md-12">   
    <?php include ("navbar1.php")?>	
</div></div>

<div class="row">
	<div class="col-md-12">    
    <?php include ("navbar2.php")?>	
</div></div>



<div class="container">
	
	<div class="s">
        <div class="row">
          <div class="col-md-12">

            <div id="news_hm">		
			 
				<div class="moduletable">
			 					
					<div class="aidanews2" >
						<div class="aidanews2_art">
							<div class="aidanews2_positions">
								<div class="aidanews2_main" >
									<div class="aidanews2_mainL">
									
									</div>
									<div class="aidanews2_mainC">
									<h1 class="aidanews2_title">
									<h1>google map</h1>
									</h1>					
														
										<div class="map1">
											<?php include ("input.php")?>
										</div>
										<div class="map">
											<?php include ("try71.php")?>
										</div>
								</div>
							</div>

							
						</div>
					</div>										
				</div>
					
					
				<div ></div>		
				
				</div>
			</div>
			</div>
				
		</div>
	</div>
		
</div>

    
<div><?php include ("footer.php")?>	</div>	 
</body>
</html>