<style>

input[type=text]{
        padding:0.5em;
       
    }
     

set_width{

min-width: 10px;
}
</style>

<div class="row">
	<div class="col-md-4">
		<form action="" method="post" class ="set_width">
			<input  type='text' name='address' required placeholder='Enter bat name' />
			<input type='submit' value='Search' />
		</form>	
	</div>	
</div>