<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>ff</title>
	<link rel="stylesheet" href="css/style.css" type="text/css">
</head>
<body>
<?php include ("sm.html")?>

</body>


</html>